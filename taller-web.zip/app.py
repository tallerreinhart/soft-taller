from flask import Flask, render_template, request, redirect, url_for
import sqlite3
from datetime import datetime

app = Flask(__name__)

def crear_db():
    conn = sqlite3.connect('base.db')
    cursor = conn.cursor()
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS trabajos (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            fecha TEXT,
            patente TEXT,
            dueño TEXT,
            kilometros TEXT,
            detalle TEXT
        )
    ''')
    conn.commit()
    conn.close()

crear_db()

@app.route('/')
def index():
    conn = sqlite3.connect('base.db')
    cursor = conn.cursor()
    cursor.execute('SELECT * FROM trabajos ORDER BY id DESC')
    trabajos = cursor.fetchall()
    conn.close()
    return render_template('index.html', trabajos=trabajos)

@app.route('/agregar', methods=['GET', 'POST'])
def agregar():
    if request.method == 'POST':
        fecha = datetime.now().strftime("%d/%m/%Y")
        patente = request.form['patente'].upper()
        dueño = request.form['dueño']
        kilometros = request.form['kilometros']
        detalle = request.form['detalle']
        conn = sqlite3.connect('base.db')
        cursor = conn.cursor()
        cursor.execute('INSERT INTO trabajos (fecha, patente, dueño, kilometros, detalle) VALUES (?, ?, ?, ?, ?)',
                       (fecha, patente, dueño, kilometros, detalle))
        conn.commit()
        conn.close()
        return redirect(url_for('index'))
    return render_template('agregar.html')

@app.route('/buscar', methods=['GET', 'POST'])
def buscar():
    trabajos = []
    if request.method == 'POST':
        patente = request.form['patente'].upper()
        conn = sqlite3.connect('base.db')
        cursor = conn.cursor()
        cursor.execute('SELECT * FROM trabajos WHERE patente = ? ORDER BY id DESC', (patente,))
        trabajos = cursor.fetchall()
        conn.close()
    return render_template('buscar.html', trabajos=trabajos)

if __name__ == '__main__':
    app.run(debug=True, host='0.0.0.0')